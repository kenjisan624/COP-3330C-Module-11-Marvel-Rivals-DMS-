/**
 * Unit tests developed for verifying that Phase I and II has been implemented
 * correctly.
 * This used JUnit tests classes and the main function is to make sure it is
 * working as initially intended design.
 * In addition, we made sure the tests passed to make Marvel Rivals Data
 * Management System a reliable application.
 */

package tests;
