package ui;

import db.Database;
import javax.swing.*;
import java.awt.*;

/**
 * Dialog windows that allow user to explore their own browser files and choose the file to later connect to
 * SQLite database to be used by Marvel Rivals Data Management Systems.
 *
 * <p> Basically, allows user to select the format allowed <code>.db</code> file, it also validates whether the input was correctly made
 * to also initialize the connection using the utility class {@link Database}</p>
 *
 * <p> <strong>Responsibilities:</strong></p>
 * <ul>
 *     <li>Prompt user to browse for .db file on user premises</li>
 *     <li>Try establishing a connection using JDBC with the file chosen</li>
 *     <li>Return an error message if not success, and display connection success if attempt succeed</li>
 *     <li>Display a confirmation message to the user to take action</li>
 * </ul>
 *
 * <p> The dialog that will be displayed is a box with the load file windows, making sure the user select the .db file
 * and validating the chosen file can be used towards the DMS. "Connected...!"</p>
 * @author Kenji Nakanishi
 * @since Phase 3
 */


public class DatabaseConnectionDialog extends JDialog {
    /** Display selected path for the SQLite database */
    private final JTextField pathField;

    /** Inform user whether the connection was successfully done   */
    private boolean ok = false;

    /**
     * Creates the model dialog prompting user to select the file (.db)
     * <p>The Menu includes the following actions:</p>
     * <ul>
     *     <li>Text field with selected file path</li>
     *     <li>Browse button to choose the file</li>
     *     <li>Connect button to validate file format and establish connection</li>
     *     <li>Cancel button to close without saving any changes</li>
     * </ul>
     *
     * @param owner the parent window that own this dialog showing buttons for the easier action of the user
     */
    public DatabaseConnectionDialog(Frame owner) {
        super(owner, "Connect to SQLite", true);
        pathField = new JTextField(28);
        // User Interface main components
        JButton browse = new JButton("Browse...");
        JButton connect = new JButton("Connect");
        JButton cancel = new JButton("Cancel");

        // Location of the file
        browse.addActionListener( e -> {
        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Select SQLite .db file");
        int r = fc.showOpenDialog(this);
        if (r == JFileChooser.APPROVE_OPTION) {
        pathField.setText(fc.getSelectedFile().getAbsolutePath());
        }
        });
        // Validation for the path and file
        connect.addActionListener( e -> {
            String path = pathField.getText().trim();
            if (path.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please choose a db. file");
                return;
            }
            try {
                Database.setUrl("jdbc:sqlite:" + path);
                Database.getConnection().close();
                ok = true;
                dispose();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Failed to connect:\n" + ex.getMessage());
            }
        });

        // Cancel button in case none .db is found
        cancel.addActionListener( e -> dispose());
        // layout portion
        JPanel row = new JPanel(new BorderLayout(8,8));
        row.add(pathField, BorderLayout.CENTER);
        row.add(browse, BorderLayout.EAST);
        JPanel buttons = new JPanel();
        buttons.add(connect);
        buttons.add(cancel);
        setLayout(new BorderLayout(10,10));
        add(new JLabel("SQLite data file:"), BorderLayout.NORTH);
        add(row, BorderLayout.CENTER);
        add(buttons, BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(owner);
    }

    /**
     * Return whether the user has been able to successfully connect to the database utilizing the file selected.
     *
     * @return {@code true} when the connection succeed; {@code false} when it does not connect.
     *
     */
    @SuppressWarnings("ConstantConditions")
    public boolean isOk(){
        return ok;
    }
}
