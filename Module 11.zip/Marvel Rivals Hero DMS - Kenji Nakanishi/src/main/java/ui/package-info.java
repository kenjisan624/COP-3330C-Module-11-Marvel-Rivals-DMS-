/**
 * This gives the user the UI (User Interface) for the Marvel Rivals Data
 * Management Systems.
 * Contains the windows format and the dialog such as load a file, table that
 * split in half for easy content visualization.
 * It also has the button action options customized colours from Marvel Rivals
 * game theme.
 * This is done with the purpose of making appealing for the user experience.
 * 
 * <p>
 * This package is responsible for rendering data, receiving I/O, and
 * coordinates
 * actions with the application logic configured in the main package
 * </p>
 */

package ui;
