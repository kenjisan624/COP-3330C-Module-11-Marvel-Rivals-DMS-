package ui;

import main.Hero;
import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.List;

/**
 * This is a model that match the list of the {@link Hero} objects to the Swing JTable,
 * making possible a visual representation of the hero data stored on the database within the Marvel Rivals
 * DMS, meaning we can see on a list that is organized by its cells category such as ID,name, HP, Mov, ult, role, wr% in ascending order
 *
 * <p> It defines the following: </p>
 *
 * <ul>
 *     <li>The column organization on the table Identity ID | Name | Health Point | Movement Speed | Ultimate Damage | Role | Win Rate </li>
 *     <li>Its updates the actions buttons logics, such as Create, Update, Delete, and Create Report on PDF format </li>
 *     <li>Handles notification system thought {@code onDirty} to signal user about changes * </li>
 * </ul>
 *
 * <p> This is an important class that make communication between hero dataset List hero and the User Interface checking for
 * its columns and rows display; Its follows Model View Controller design principles.</p>
 *
 * @author Kenji Nakanishi
 * @since Phase 3
 */
public class HeroTableModel extends AbstractTableModel {

    /**
     * Constructs a new {@code HeroTableModel} with empty list;
     * <p> Table model will be initialized by the GUI and then use {@link javax.swing.JTable} to represent
     * graphic to the user. Finally, list will be updated using {@link #setAll(List)} and {@link #add(Hero)}</p>
     */
    public HeroTableModel() {

    }

    /** Name of the table columns in order     */
    private final String[] cols = {"ID","Name","HP","Move","Ult","Role","WinRate"};
    /** This is an internal use only to store temporary current hero data that is displayed in the table   */
    private final List<Hero> data = new ArrayList<>();
    /** Asterisk shows the user when data are being modified.     */
    private Runnable onDirty;

    /**
     * Set a callback to be executed when the table has undergone changes or "dirty"
     *
     * @param r a {@link Runnable} executed when the data has changed
     */
    public void setOnDirty(Runnable r) { this.onDirty =r;}

    /**
     * This will return a copy of the current hero list.
     * <p> Prevents external modification from affecting to the model</p>
     * @return a new List that contains current heroes in the table
     */
    public List<Hero> snapshot() {
        return new ArrayList<>(data);
    }

    /**
     * Refresh the content by replacing all the heros in the table with the provided List
     * @param heroes the most current heroes to be displayed
     */
    public void setAll(List<Hero> heroes) {
        data.clear();
        data.addAll(heroes);
        fireTableDataChanged();
        markDirty();
    }

    /**
     * Adds a new hero to the table model and check with the JTable for updates
     * @param h the hero to be added
     */
    public void add(Hero h){
        int i = data.size();
        data.add(h);
        fireTableRowsInserted(i, i);
        markDirty();
    }

    /**
     * Removes the selected hero of the list row index; if invalid mouse positioning, it will be ignored
     *
     * @param modelRow is the row index to be removed
     */
    public void remove(int modelRow) {
        if (modelRow < 0 || modelRow >= data.size()) return;
        data.remove(modelRow);
        fireTableRowsDeleted(modelRow, modelRow);
        markDirty();
    }

    /**{@inheritDoc}*/
    @Override public int getRowCount() { return data.size(); }
    /**
     *
     * Return the number of columns that is going to be displayed in the JTable
     * {@code cols} an array that contain in organized patterns information of:
     * ID, Hero Name, HP, Movement speed, Ultimate Damage, Role, and win rate.
     *
     * @return the total numbers of columns
     * {@inheritDoc}
     * */
    @Override public int getColumnCount() { return cols.length; }
    /**
     *
     * Return the display name of the columns
     *
     * It will be shown in fixed column fields and cells name for specific list
     * @param c index of the column
     * @return the column header label
     *
     * {@inheritDoc}*/
    @Override public String getColumnName(int c) { return cols[c]; }
    /**
     *
     * Indicates if the cell can be editable by the user
     *
     * Since the GUI allow user easier access to modify data, this method will allow to control
     * which cell can be modified, such as updated or delete.
     * @param r the row index
     * @param c the colum index
     * @return {@code false} 100% always.
     * {@inheritDoc}*/
    @Override public boolean isCellEditable(int r, int c) { return false; }


    /**
     *  This will return the value that is stored in the specific row and column making possible to obtain information of the displayed list
     * @param r        the row whose value is to be queried
     * @param c     the column whose value is to be queried
     * @return the value to be displayed in the table cell
     */
    @Override public Object getValueAt(int r, int c) {
        Hero h = data.get(r);
        return switch (c) {
            case 0 -> h.getIdentityHeroID();
            case 1 -> h.getHeroName();
            case 2 -> h.getHealthPoint();
            case 3 -> h.getMovementSpeed();
            case 4 -> h.getUltDamage();
            case 5 -> h.getHeroRole();
            case 6 -> h.getWinRate();
            default -> "";
        };
    }

    /**
     * This will set and update to the object with the given values
     *
     * <p> Basically, it will give the values assigned by editing the current values of the {@link Hero}. It will check with formatting if the user input
     * can be used, if not the changes will not be implemented and ignored.</p>
     * @param v   value to assign to cell | new values
     * @param r   row of cell index
     * @param c  column of cell index
     */
    @Override public void setValueAt(Object v, int r, int c) {
        Hero h = data.get(r);
        try {
            String id = h.getIdentityHeroID();
            String name = h.getHeroName();
            int hp = h.getHealthPoint();
            int move = h.getMovementSpeed();
            int ult = h.getUltDamage();
            String role = h.getHeroRole();
            double rate =h.getWinRate();

            switch (c){
                case 0 -> id = String.valueOf(v);
                case 1 -> name = String.valueOf(v);
                case 2 -> hp = Integer.parseInt(v.toString());
                case 3 -> move = Integer.parseInt(v.toString());
                case 4 -> ult = Integer.parseInt(v.toString());
                case 5 -> role = String.valueOf(v);
                case 6 -> rate = Double.parseDouble(v.toString());
            }
            data.set(r, new Hero(id,name,hp,move,ult,role,rate));
            fireTableRowsUpdated(r, r);
            markDirty();
        } catch (Exception ignored) { }
    }

    /**
     * Marks the table that it is undergoing modification onDirty callback
     */
    private void markDirty() { if(onDirty != null) onDirty.run();}
}
