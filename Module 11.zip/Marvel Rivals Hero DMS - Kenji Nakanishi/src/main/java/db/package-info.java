/**
 * It provides with database connectivity function and schema connecting utilities
 * making Marvel Rivals Systems to establish connection with SQLite, it also makes sure
 * that the URL files can be opened, tables and index exists. 
 * <p> This db package uses repository classes to be able to perform CRUD + customer methods
 * operation on heroes database.
 * 
 */ 
 
package db;
