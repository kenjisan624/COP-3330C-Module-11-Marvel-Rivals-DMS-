package main;

import java.util.Locale;

/**
 * This will represent each of the Marvel Rivals Hero Data Management System
 * Each hero will contain attributes such as ID, HP, Mov speed, ultimate damage, role, and win rate in percentage.
 * This class provides to other classes as a helper the formatting for the hero data to be displayed.
 *
 * @author Kenji Nakanishi
 * @since Phase 1
 *
 */
public class Hero{
    /**     *  Used to limit range of CSV comma separated value file on Phase 1 */
    public static final String FILE_DELIM = " - ";
    /**     * Same for - hyphen formatting separating each value     */
    public static final String FILE_SPLIT_REGEX = "\\s*-\\s*";
    private final String identityHeroID;
    private final String heroName;
    private final int healthPoint;
    private final int movementSpeed;
    private final int ultDamage;
    private final String heroRole;
    private final double winRate;

    /**
     * This will create a new {@code Hero} with all the required attributes
     * @param identityHeroID is a 3 digits unique hero identity
     * @param heroName the full name that has 3 words maximum
     * @param healthPoint from 250 ~ 900
     * @param movementSpeed from 6~9
     * @param ultDamage from 300~9999
     * @param heroRole there are three roles Duelist | Strategist | Vanguard
     * @param winRate from 0.00 % ~ 100.00%
     */

    public Hero (String identityHeroID, String heroName, int healthPoint, int movementSpeed,
                 int ultDamage, String heroRole, double winRate) {
        this.identityHeroID = identityHeroID;
        this.heroName = heroName;
        this.healthPoint = healthPoint;
        this.movementSpeed = movementSpeed;
        this.ultDamage = ultDamage;
        this.heroRole = heroRole;
        this.winRate = winRate;
    }

    /**
     *Return the 3 digits identity ID assigned to specific hero
     *
     * @return hero's 3 digits unique ID
     */
    public String  getIdentityHeroID() {
        return identityHeroID;
    }
    /**
     * Return the full name that can only be composed by 3 words maximum
     * @return full name of the hero
     */
    public String getHeroName() {
        return heroName;
    }

    /**
     * Return the total HP of the hero, accepted value range from 250~900
     * @return health point of the hero  */
    public int getHealthPoint() {return healthPoint;}

    /**
     * Returns how fast does a characters move in the game; the range is from 6~9
     * @return the movement speed of the hero  */
    public int getMovementSpeed() {
        return movementSpeed;
    }
    /**
     * Return the ultimate damage ability points range from 350~9999
     * @return the ultimate damage for the specific hero  */
    public int getUltDamage() {return ultDamage;}

    /**
     * Return the hero assigned role
     * @return the role of the specific hero  */
    public String getHeroRole(){
        return heroRole;
    }

    /**
     * Returns the win rate expressed in percentage
     * @return the percentage of winning rate ranging 0.00~100.00%  */
    public double getWinRate(){
        return winRate;
    }

    /**Formatting strings to be displayed in the console based app ver
     *
     * @return the format that will be used in data string
     */
    @Override
    public String toString() {
        return String.format(Locale.ROOT, "%s - %s - %d - %d - %d - %s - %.2f%%", identityHeroID, heroName, healthPoint, movementSpeed, ultDamage, heroRole, winRate);
    }
    /**
     * Converts the CSV or Text file to console based app readable format with the hyphen
     * @return a hyphen delimited line containing heroes attributes
     */
    public String toFileLine(){
        return String.format(Locale.ROOT, "%s" + FILE_DELIM + "%s" + FILE_DELIM + "%d" + FILE_DELIM + "%d" +
                        FILE_DELIM + "%d" + FILE_DELIM + "%s" + FILE_DELIM + "%.2f",
                identityHeroID, heroName, healthPoint, movementSpeed, ultDamage, heroRole, winRate);
    }
    /**
     * It builds again the {@link Hero} object from the CSV format;
     * lines of the file must be exactly typed with hyphens to work properly.
     *
     * @param line containing the hero data
     * @return rebuild {@link Hero} data
     * @throws IllegalArgumentException when line is not correctly formatted
     */
    public static Hero fromFileLine(String line) {
        if (line == null || line.trim().isEmpty() ) {
            throw new IllegalArgumentException("Empty or null");
        }
        String[] parts = line.split(FILE_SPLIT_REGEX,7);
        if (parts.length != 7) {
            throw new IllegalArgumentException("Invalid hero: " + line);
        }
        try {
            String id       = parts[0].trim();
            String name     = parts[1].trim();
            int hp          = Integer.parseInt(parts[2].trim());
            int move        = Integer.parseInt(parts[3].trim());
            int ult         = Integer.parseInt(parts[4].trim());
            String role     = parts[5].trim();
            String wrRaw    = parts[6].trim().replace("%", "");
            double rate     = Double.parseDouble(wrRaw);

            return new Hero(id, name, hp, move, ult, role, rate);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Invalid hero: " + line, e);
        }
    }
}