package main;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.List;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;

/**
 * Provide logic for the Marvel Rivals Data Management System.
 * Includes validation for CRUD operation, CSV/TXT imports processors, sorting, and PDF generation functionalities.
 *
 * <p>This is a helper service method that supports GUI and console based application connections
 * working with {@link HeroRepository}. It also ensures that all data of the heroes are validated before taking place such as the CRUD methods.
 *</p>
 *
 * <p><strong>Responsibilities:</strong></p>
 * <ul>
 *     <li>Validate attributes formatting (ID, Name, HP,Mov speed. Role, Win Rate)</li>
 *     <li>Make CRUD operations possible using {@link HeroRepository}</li>
 *     <li>Sort heroes when displaying by win rate</li>
 *     <li>Generate a PDF using iText Libraries</li>
 * </ul>
 * <p>This method will be used more with the implementation of the Phase III GUI replacing more of the NavigationMenu that was inteded for Phase I and console based Menu</p>
 *
 * @author Kenji Nakanishi
 * @since Phase 3
 */
public class HeroFunctionalities {
    /**
     * Represent the result of the hero import method.
     * It will tell the user how many was successfully added, skipped, duplicated, or invalid.
     *
     */
    public static class ImportResult {

        /**
         * Number of heroes added
         */
        public final int added;
        /**
         * Numebr of heroes skipped
         */
        public final int duplicates;
        /**
         * Number of heroes with invalid data or format
         */
        public final int errors;
        /**
         * Number of lines skipped
         */
        public final int skipped;

        /**
         * Creates a result contained for imported file
         * @param a number of correctly added
         * @param d number of duplicated found
         * @param e number of invalid lines
         * @param s number of skipped lines
         */
        public ImportResult(int a, int d, int e, int s) {
            added = a;
            duplicates = d;
            errors = e;
            skipped = s;
        }

        /**
         * Return a text summary of the import statistics
         * @return formatted summary of import
         */
        @Override
        public String toString() {
            return "Imported: " + added + " | Duplicates: " + duplicates +
                    " | Errors: " + errors + " | Skipped: " + skipped;
        }
    }

    /**
     * Reference to the repository storing the heroes
     */
    private final HeroRepository repo;

    /**
     * Constructs a new {@code HeroFunctionalities} function.
     * Connects the repository allowing CRUD operationg and validation to make sure data is corecct.
     *
     * @param repo the repository used to store and retrieve heroes
     */
    public HeroFunctionalities(HeroRepository repo) {

        this.repo = repo;
    }

    /**
     * Adds a new hero after all validations has passed
     * @param h the hero to be added
     * @return {@code true} when all was validated fine
     */
    public boolean addHero(Hero h) { validate(h); return repo.save(h); }

    /**
     * Returns all heroes stored in the repository
     * @return list of heroes
     */
    public List<Hero> listHeroes() { return repo.findAll(); }

    /**
     * Updates an existing hero after validation completed
     * @param h the updated hero objetc
     * @return {@code true} if the hero existed and was updated correctly.
     */
    public boolean updateMarvelHero(Hero h) { validate(h);  return repo.update(h); }

    /**
     * Deletes a hero record by tying ID
     * @param id the unique Identity ID
     * @return {@code true} when deletion was completed
     */
    public boolean removeMarvelHeroById(String id) {return repo.deleteById(id); }

    /**
     * Return heroes by win rate from the highest to lowest.
     * @return sorted list of heroes by win rate
     */
    public List<Hero> topByWinRate() {
        List<Hero> all = new ArrayList<>(repo.findAll());
        all.sort(Comparator.comparingDouble(Hero::getWinRate).reversed());
        return all;
    }

    /**
     * Load hero from the CSV/TXT file and check line by line for invalid entries, counting them
     * to print at the end to the user; it will use {@link ImportResult} to generate the count and report.
     * @param path
     * @return
     */
    public ImportResult loadFromSavedFile(Path path) {
        int added = 0, dups = 0, errors = 0, skipped = 0;

        try (BufferedReader br = Files.newBufferedReader(path)) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;

                String[] info = line.split("\\s*-\\s*", 7);
                if (info.length != 7) {
                    skipped++;
                    continue;
                }
                String id = info[0].trim(), name = info[1].trim(), hpS = info[2].trim(),
                        spS = info[3].trim(), ultS = info[4].trim(), role = info[5].trim(), wrS = info[6].trim();

                if (!isValidHeroId(id)) {
                    errors++;
                    continue;
                }
                Integer hp = HealthPointFormat(hpS);
                if (hp == null) {
                    errors++;
                    continue;
                }
                Integer sp = MovementSpeedFormat(spS);
                if (sp == null) {
                    errors++;
                    continue;
                }
                Integer ult = UltDamageFormat(ultS);
                if (ult == null) {
                    errors++;
                    continue;
                }
                String roleN = HeroRoleFormat(role);
                if (roleN == null) {
                    errors++;
                    continue;
                }
                Double wr = WinRateFormat(wrS);
                if (wr == null) {
                    errors++;
                    continue;
                }
                if (repo.existsById(id)) {
                    dups++;
                    continue;
                }

                Hero h = new Hero(id, name.trim().replaceAll("\\s+", " "),
                        hp, sp, ult, roleN, wr);
                repo.save(h);
                added++;
            }
        } catch (IOException ioe) {
            throw new RuntimeException("Error loading from saved file", ioe);
        }
        return new ImportResult(added, dups, errors, skipped);
    }

    /**
     * Generate the PDF by highest Win rate character to the lowest using iText library.
     * <p>The PDF will include all the heroes attributes in a table format</p>
     * @param out the output file path for the PDF that has been generated
     * @return the path to the completed PDF
     * @throws IllegalStateException when no heroes available
     */
    public Path generateWinRateReport (Path out) {
        List<Hero> list = topByWinRate();
        if (list.isEmpty()) throw new IllegalStateException("No heroes to be added to the PDF.");

        try {
            Document doc = new Document(PageSize.A4);
            PdfWriter.getInstance(doc, new FileOutputStream(out.toFile()));
            doc.open();

            Font title = new Font(Font.FontFamily.TIMES_ROMAN, 22, Font.BOLD);
            doc.add(new Paragraph("Marvel Rivals Heroes Win Rate % Report", title));
            doc.add(new Paragraph(" "));

            PdfPTable t = new PdfPTable(7);
            t.setWidthPercentage(100);
            t.setWidths(new float[]{1.2f,2.5f,1.2f,1.2f,1.5f,2f,1.5f});

            Font head = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD, BaseColor.WHITE);
            BaseColor red = new BaseColor(255, 0, 0);
            for (String h : new String[] {"ID","Hero Name","Health Point","Mov. Speed","Ultimate Damage","Hero Role","Win Rate (%)"}) {
                PdfPCell c = new PdfPCell(new Phrase(h, head));
                c.setBackgroundColor(red);
                c.setHorizontalAlignment(Element.ALIGN_CENTER);
                t.addCell(c);
            }

            for (Hero h : list) {
                t.addCell(h.getIdentityHeroID());
                t.addCell(h.getHeroName());
                t.addCell(Integer.toString(h.getHealthPoint()));
                t.addCell(Integer.toString(h.getMovementSpeed()));
                t.addCell(Integer.toString(h.getUltDamage()));
                t.addCell(h.getHeroRole());
                t.addCell(String.format("%.2f", h.getWinRate()));
            }
            doc.add(t);
            doc.close();
            return out;
        } catch (Exception e) {
            throw new RuntimeException("PDF Generation error", e);
        }
    }

    /**
     * Validates all the heroes attributes following project layout
     * @param h the hero to be validated
     * @throws IllegalStateException when attribute format is invalid
     */
    private void validate (Hero h) {
        if(!isValidHeroId(h.getIdentityHeroID())) throw new IllegalArgumentException("ID must be 3 digits");
        if (h.getHeroName()==null || h.getHeroName().isBlank() || h.getHeroName().trim().split("\\s+").length>3)
            throw new IllegalArgumentException("Name must be 1–3 words.");
        if (h.getHealthPoint()<250 || h.getHealthPoint()>900) throw new IllegalArgumentException("HP 250–900.");
        if (h.getMovementSpeed()<6 || h.getMovementSpeed()>9) throw new IllegalArgumentException("Speed 6–9.");
        if (h.getUltDamage()<300 || h.getUltDamage()>9999) throw new IllegalArgumentException("Ult 300–9999.");
        if (HeroRoleFormat(h.getHeroRole())==null) throw new IllegalArgumentException("Role Duelist/Strategist/Vanguard.");
        if (h.getWinRate()<0 || h.getWinRate()>100) throw new IllegalArgumentException("WinRate 0–100.");
    }

    /**
     * Validate the hero ID format must be 3 digits
     * @param id hero ID
     * @return true when valid
     */
    public static boolean isValidHeroId(String id) { return id!=null && id.matches("\\d{3}"); }

    /**
     * Parse and validation of the HP between 250~900
     *
     * @param s text input from user
     * @return integer HP value
     */
    public static Integer HealthPointFormat(String s){ try{int v=Integer.parseInt(s); return (v<250||v>900)?null:v;}catch(Exception e){return null;} }

    /**
     * Parse and validad movement speed value is between 6~9
     * @param s text input from user
     * @return integer speed value
     */
    public static Integer MovementSpeedFormat(String s){ try{int v=Integer.parseInt(s); return (v<6||v>9)?null:v;}catch(Exception e){return null;} }

    /**
     * parse and validates ultimate damage ranged between 300~9999
     *
     * @param s text input from user
     * @return integer ult damage
     */
    public static Integer UltDamageFormat(String s){ try{int v=Integer.parseInt(s); return (v<300||v>9999)?null:v;}catch(Exception e){return null;} }

    /**
     * verify that hero role is in those of accepted format
     * @param role text input form user
     * @return normalized role as duelist, strategist, or vanguard
     */
    public static String HeroRoleFormat(String role) {
        if (role == null) return null;
         return switch (role.trim().toLowerCase(Locale.ROOT)) {
            case "duelist" -> "Duelist";
            case "strategist" -> "Strategist";
            case "vanguard" -> "Vanguard";
            default -> null;
        };
    }

    /**
     * Parses and validate win rate between range 0.00~100%
     *
     * @param s text input from user
     * @return win rate as double value
     */
    public static Double WinRateFormat(String s) {try{double v=Double.parseDouble(s); return (v<0 || v>100)?null:v;} catch (Exception e){return null;} }
    }