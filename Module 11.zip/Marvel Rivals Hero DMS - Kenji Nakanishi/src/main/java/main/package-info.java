/**
 * Contain the CRUD methods and the logic of the Marvel Rivals Data Management
 * Systems
 * This package includes repositories, interfaces, and functional classes that
 * make data handling possible.
 * It also has the rules that each field will have such as allowed characters,
 * health point, Ult Damage, Role, and win rate.
 * 
 * <p>
 * These classes are the backend and these java files are used on the User
 * Interface and in the database phases
 * </p>
 */

package main;
