package main;

import java.util.*;

/**
 * This will use the HeroRepository implementation; it is going to be used for testing of the Phase I and II
 */
public class InMemoryHeroRepository implements main.HeroRepository {
    /**
     * Creates a new instance of {@code InMemoryRepository} backed by the{@link HashMap}.
     * It stores the hero records in the system memory = temporarily for testing purposes on the Phase I and II.
     *
     * <p>CRUD operation are performed directly in-memory mapping. </p>
     */
    public InMemoryHeroRepository() {

    }
    private final Map<String, Hero> store = new HashMap<>();

    @Override public boolean save(main.Hero hero) {
        if (store.containsKey(hero.getIdentityHeroID())) return false;
        store.put(hero.getIdentityHeroID(), hero);
        return true;
    }

    @Override
    public Hero findById(String id) {
        return store.get(id);
    }

    @Override
    public List<main.Hero> findAll() {
        return new ArrayList<>(store.values());
    }

    @Override
    public boolean update(main.Hero hero) {
        if (!store.containsKey(hero.getIdentityHeroID())) return false;
        store.put(hero.getIdentityHeroID(), hero);
        return true;
    }
    @Override
    public boolean deleteById(String id) {
        return store.remove(id) != null;
    }

    @Override
    public boolean existsById(String id) {
        return store.containsKey(id);
    }
}
